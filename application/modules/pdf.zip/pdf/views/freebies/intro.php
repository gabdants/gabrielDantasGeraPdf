        <main>
            <!--Main layout-->
            <div class="container">

                <!--Page heading-->
                <div class="row wow fadeIn" data-wow-delay="0.2s">
                    <div class="col-md-12 mt-5">
                        <h2 class="h1-responsive font-bold" style="float: left;">Lista de compras
                            <small class="text-muted">- Geral</small>
                        </h2>
                        <button type="submit" class="btn btn-default active" style="float: right;" onclick="location.href='<?php echo base_url();?>index.php/Cliente/index'" >HOME</button>

                    </div>
                </div>
                <!--/.Page heading-->
                <hr>
