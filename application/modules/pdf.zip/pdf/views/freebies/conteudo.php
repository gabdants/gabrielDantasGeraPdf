<div id="btCad" data-wow-delay="0.2s">
<button class="btn btn-primary" onclick="location.href='<?php echo base_url();?>index.php/Cliente/cadastroProd'">Cadastrar nova compra!</button>
</div>

<div id="btHis" data-wow-delay="0.2s">
<button class="btn btn-primary" onclick="location.href='<?php echo base_url();?>index.php/Cliente/lista'">Consultar histórico de compras!</button>

</div>

