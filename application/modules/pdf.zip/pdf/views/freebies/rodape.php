        <!-- SCRIPTS -->

        <!-- JQuery -->
        <script type="text/javascript" src="<?= base_url() ?>assets/js/jquery-3.1.1.min.js"></script>

        <!-- Bootstrap dropdown -->
        <script type="text/javascript" src="<?= base_url() ?>assets/js/popper.min.js"></script>

        <!-- Bootstrap core JavaScript -->
        <script type="text/javascript" src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>

        <!-- MDB core JavaScript -->
        <script type="text/javascript" src="<?= base_url() ?>assets/js/mdb.min.js"></script>

        <script>
            new WOW().init();
        </script>

        <footer>
        <button type="button" class="btn btn-info btn-block" onclick="location.href='<?php echo base_url();?>index.php/Cliente/lista'">Consulta geral</button>
        </footer>

</body>



</html>